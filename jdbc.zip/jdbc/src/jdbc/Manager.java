package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Manager {
	public static void main(String[] args) throws Exception {
		Class.forName("org.h2.Driver");
		Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
		Statement stmt = con.createStatement();
		String sql = "Select * from USERDEMO";
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()){
			System.out.println("Id" + rs.getInt(1));
			System.out.println("Email" + rs.getString(2));
			System.out.println("Firstname" + rs.getString(3));
			System.out.println("lastname" + rs.getString(4));
			System.out.println("Username" + rs.getString(6));
			System.out.println("-------------");
		}
	}
}
