package com.nik;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Welcome {

	@RequestMapping("/")
	public String welcome() {
		return "login";
	}
	@RequestMapping("/home")
	public String home() {
		return "login";
	}
	
	@RequestMapping("/hello")
	public String hello() {
		return "hello";
	}
}
