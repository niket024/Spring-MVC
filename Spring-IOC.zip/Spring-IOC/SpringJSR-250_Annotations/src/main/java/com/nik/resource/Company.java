package com.nik.resource;

public class Company
{
	private String compName;

	public String getCompName()
	{
		return compName;
	}

	public void setCompName(String compName)
	{
		this.compName = compName;
	}
}