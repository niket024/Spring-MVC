package java8InterfaceExample;

public class Manager implements A
{

	public static void main(String[] args)
	{
		Manager m1 = new Manager();
		m1.test();
		A.test1();
	}
}
