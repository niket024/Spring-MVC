package com.nik;

public class A
{
	public void doTask()
	{
		System.out.println("Do some task.");
	}
}
