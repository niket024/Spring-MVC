package com.nik;

public class Student
{

}
