package com.nik;

public interface A
{
	default void test()
	{
		System.out.println("test");
	}
}
