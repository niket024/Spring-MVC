package com.nik.model;

public class User
{

}
