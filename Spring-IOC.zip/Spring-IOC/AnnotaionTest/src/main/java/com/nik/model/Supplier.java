package com.nik.model;

public class Supplier
{

}
