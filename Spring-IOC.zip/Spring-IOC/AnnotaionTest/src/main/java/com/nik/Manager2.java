package com.nik;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nik.appconfig.DbConfig;
import com.nik.model.Product;

public class Manager2
{
	private static ApplicationContext applicationContext;

	public static void main(String[] args)
	{
		applicationContext = new AnnotationConfigApplicationContext(
				DbConfig.class);

		System.out.println(applicationContext.getBean(Product.class)
				.getCategories() == null ? "Null" : "Categories");

		System.out.println(applicationContext.getBean(Product.class)
				.getSupplier() == null ? "Null" : "Supplier");
	}
}
