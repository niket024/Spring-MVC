public interface Area
{
	public void getArea();
	
}
