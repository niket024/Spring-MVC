import java.util.Scanner;

public class LooseCoupling
{
	static void common(Area a1)
	{
		a1.getArea();
	}

	public static void main(String[] args)
	{

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the entity");
		String entity = sc.next();
		if (entity.equals("circle")) {
			common(new Circle());
		} else if (entity.equals("square")) {
			common(new Square());
		}
		sc.close();
	}
}
