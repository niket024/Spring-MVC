public class Square implements Area
{
	@Override
	public void getArea()
	{
		System.out.println("area of square");

	}
}
